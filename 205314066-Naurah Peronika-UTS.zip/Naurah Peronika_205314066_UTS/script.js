$(document).ready(function () {

  $(window).scroll(function () {
    if (this.scrollY > 20) {
      $(".navbar").addClass("sticky");
    } else {
      $(".navbar").removeClass("sticky");
    }

    if (this.scrollY > 500) {
      $(".scroll-up-btn").addClass("show");
    } else {
      $(".scroll-up-btn").removeClass("show");
    }

    $(".fadein").each(function (i) {
      var bottom_of_element = $(this).offset().top + $(this).outerHeight();
      var bottom_of_window = $(window).scrollTop() + $(window).height();

      if (bottom_of_window > bottom_of_element) {
        $(this).addClass("showme");
      }
      if (bottom_of_window < bottom_of_element) {
        $(this).removeClass("showme");
      }
    });
  });

  $(".scroll-up-btn").click(function () {
    $("html").animate({ scrollTop: 0 });
  });

  var typed = new Typed(".typing", {
    strings: ["Independent!", "Adaptive!", "Brave!", "Queen!"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true,
  });

  var typed = new Typed(".typing2", {
    strings: ["Independent!", "Adaptive!", "Brave!", "Queen!"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true,
  });

  $(".menu-btn").click(function () {
    $(".navbar .menu").toggleClass("active");
    $(".menu-btn i").toggleClass("active");
  });

  $(".carousel").owlCarousel({
    margin: 20,
    loop: true,
    autoplayTimeOut: 2000,
    autoplayHoverPause: true,
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      600: {
        items: 2,
        nav: false,
      },
      1000: {
        items: 3,
        nav: false,
      },
    },
  });

  $('#jumlahHobi').on('change', function () {
    const jumlahHobiInput = $(this).val();
    const hobiListContainer = $('#hobiList');
    hobiListContainer.html('');

    for (let i = 0; i < jumlahHobiInput; i++) {
      let checkbox = $('<input>').attr({
        type: 'checkbox',
        name: 'hobi'
      });

      let label = $('<label>').text(`Hobi ${i + 1}: `);

      let input = $('<input>').attr({
        type: 'text',
        name: `hobi-${i + 1}`
      });

      hobiListContainer.append(checkbox, label, input, $('<br>'));
    }
  });

  $('#generateHobiList').on('click', function () {
    const firstName = $('#firstName').val();
    const lastName = $('#lastName').val();
    const email = $('#email').val();
    const jumlahHobi = $('#jumlahHobi').val();
    const hobbies = [];
  
    $('input[name="hobi"]:checked').each(function () {
      hobbies.push($(this).next().next().val());
    });
  
    // Memeriksa apakah semua data yang diperlukan telah dimasukkan
    if (firstName && lastName && email && jumlahHobi && hobbies.length > 0) {
      // Membuat kalimat output
      let output = `Hallo, nama saya ${firstName} ${lastName}, dengan email ${email}, saya mempunyai sejumlah ${jumlahHobi} pilihan hobi yaitu`;
  
      for (let i = 0; i < hobbies.length; i++) {
        output += ` ${hobbies[i]},`;
      }
  
      output = output.slice(0, -1); // Menghapus koma ekstra di akhir
      output += `, dan saya menyukai ${hobbies.join(', ')}.`;
  
      // Menampilkan output
      alert(output); // Ini akan menampilkan pesan sederhana. Anda dapat menggunakan modal atau cara lain jika diinginkan.
  
      console.log('Selected hobbies:', hobbies);
      console.log('Output message:', output);
    } else {
      alert('Mohon lengkapi semua data terlebih dahulu.'); // Memberi tahu pengguna untuk melengkapi semua data
    }
  });
  
});
