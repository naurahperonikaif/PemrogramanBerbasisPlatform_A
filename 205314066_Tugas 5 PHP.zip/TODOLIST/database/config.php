<?php
// Informasi koneksi ke database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'todolist';

// Membuat koneksi
$koneksi = new mysqli($host, $username, $password, $database);

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
