<?php
// Memulai sesi
session_start();

// Masukkan file config.php untuk koneksi database
include('../database/config.php');

// Cek apakah tombol login ditekan
if (isset($_POST['username'], $_POST['password'])) {
    // Ambil data dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mendapatkan informasi pengguna berdasarkan username
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $koneksi->query($query);

    if ($result && $result->num_rows > 0) {
        // Pengguna ditemukan, verifikasi password
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Password cocok, sesi login ditetapkan
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['id']; // Menyimpan user_id ke dalam sesi
            // Redirect ke halaman todolist.php
            header('Location: ../view/todolist.php');
            exit;
        }
    }
}

// Jika kredensial tidak sesuai atau tidak ditemukan, arahkan kembali ke halaman login
header('Location: ../view/login.php');
exit;
