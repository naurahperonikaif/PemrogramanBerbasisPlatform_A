<?php
include '../database/config.php';

// Mulai session jika belum dimulai
session_start();

// Proses insert data
if (isset($_POST['add'])) {
    $task = $_POST['task'];
    $user_id = $_SESSION['user_id']; // Ambil user_id dari session yang sudah login
    $q_insert = "INSERT INTO tasks (tasklabel, taskstatus, user_id) VALUES ('$task', 'open', '$user_id')";
    $run_q_insert = mysqli_query($koneksi, $q_insert);

    if ($run_q_insert) {
        header('Refresh:0; url=todolist.php');
    }
}

// Select
$user_id = $_SESSION['user_id']; // Ambil user_id dari session yang sudah login
$q_select = "SELECT * FROM tasks WHERE user_id = '$user_id' ORDER BY taskid DESC";
$run_q_select = mysqli_query($koneksi, $q_select);

// Delete
if (isset($_GET['delete'])) {
    $task_id = $_GET['delete'];
    $q_delete = "DELETE FROM tasks WHERE taskid = '$task_id' AND user_id = '$user_id'";
    $run_q_delete = mysqli_query($koneksi, $q_delete);

    header('Refresh:0; url=todolist.php');
}

// Update
if (isset($_GET['done'])) {
    $task_id = $_GET['done'];
    $status = ($_GET['status'] == 'open') ? 'close' : 'open';
    $q_update = "UPDATE tasks SET taskstatus = '$status' WHERE taskid = '$task_id' AND user_id = '$user_id'";
    $run_q_update = mysqli_query($koneksi, $q_update);

    header('Refresh:0; url=todolist.php');
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>To Do List</title>
    <!-- favicon -->
    <link rel="icon" href="../assets/fav.png" type="image/x-icon">
    <!-- style -->
    <link rel="stylesheet" href="../assets/style.css">
    <!-- Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
    <!-- font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

    <style>
        .data {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            border-radius: 5px;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.2);
        }

        .foto {
            border-radius: 50%;
        }

        .title-data {
            font-size: 14px;
            font-weight: 600;
        }
    </style>
</head>

<body>
    <section class="container">
        <div class="data">
            <img src="../assets/foto.jpeg" alt="foto" class="foto" width="100" height="100">
            <div class="title-data">
                <p>Nama : Naurah Peronika</p>
                <p>NIM : 205314066</p>
            </div>
            <!-- Tombol Logout -->
            <form action="../controller/logout.php" method="POST">
                <button type="submit" name="logout" onclick="return confirm('Apakah anda yakin untuk keluar ?')">Logout</button>
            </form>
        </div>
        <div class="header">
            <div class="title">
                <i class="fa-solid fa-book-bookmark"></i>
                <span>To Do List</span>
            </div>
            <div>

            </div>
        </div>

        <div class="content">
            <div class="card">
                <form action="" method="post">
                    <input type="text" name="task" class="input-control" placeholder="< Teks to do >" required>
                    <div class="text-right">
                        <button type="submit" name="add">Tambah</button>
                    </div>
                </form>
            </div>
            <?php if (mysqli_num_rows($run_q_select) > 0) {
                while ($r = mysqli_fetch_array($run_q_select)) { ?>
                    <div class="card">
                        <div class="task-item <?= $r['taskstatus'] == 'close' ? 'done' : '' ?>">
                            <div>
                                <input type="checkbox" onclick="window.location.href = '?done=<?= $r['taskid'] ?>&status=<?= $r['taskstatus'] ?>'" <?= $r['taskstatus'] == 'close' ? 'checked' : '' ?>>
                                <span><?= $r['tasklabel'] ?></span>
                            </div>
                            <div>
                                <a href="?delete=<?= $r['taskid'] ?>" class="icon" title="Remove" onclick="return confirm('Apakah anda yakin untuk menghapus data ini ?')"><i class="fa-solid fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                <?php }
            } else { ?>
                <div class="titles">*Belum ada task</div>
            <?php } ?>
        </div>
    </section>
</body>

</html>